public class Buku {
    public String judulBuku;
    public int tahunTerbit;
    public String penulis;
    public int halamanBuku;
    public String genreBuku;

    public Buku(String judulBuku, int tahunTerbit, String penulis, int halamanBuku, String genreBuku) {
        this.judulBuku = judulBuku;
        this.tahunTerbit = tahunTerbit;
        this.penulis = penulis;
        this.halamanBuku = halamanBuku;
        this.genreBuku = genreBuku;
    }

}