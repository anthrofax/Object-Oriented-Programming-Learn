class Hewan {
    protected String jenisSuara;

    public void bersuara() {
        System.out.println(this.jenisSuara);
    }
}